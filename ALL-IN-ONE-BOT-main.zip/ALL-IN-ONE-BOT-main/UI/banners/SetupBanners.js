const setupBanners = {
    helpBanner : 'https://i.ibb.co/23C0zG31/standard-1.gif',
    verificationBanner : 'https://i.ibb.co/pjHDXzXx/static.png',
    ticketBanner : 'https://i.ibb.co/h1DBsRnv/ticket.gif',
    autovcBanner : 'https://i.ibb.co/mk6Tj1r/autovc.gif',
};

module.exports = setupBanners;
