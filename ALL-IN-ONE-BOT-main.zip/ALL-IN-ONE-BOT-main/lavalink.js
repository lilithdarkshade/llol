
module.exports = {
    enabled: true, 
    lavalink: {
        name: "GlaceYT",
        password: "glaceyt",
        host: "193.226.78.187",
        port:  3543,
        secure: false
    }
};
